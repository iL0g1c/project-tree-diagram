import discord
from discord import app_commands
from discord.ext import commands
import grpc
from protos import database_service_pb2, database_service_pb2_grpc
from google.protobuf.timestamp_pb2 import Timestamp
import TreeDiagramBot as TreeDiagram
import utils.validateUser as validateUser

class Intelligence(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    intelligence_group = app_commands.Group(name="intelligence", description="GeoFS Intelligence Commands")

    @intelligence_group.command(name="add-id", description="Add a pilot to the ID storage database.")
    @app_commands.describe(discord_id="Discord ID of the pilot.", geofs_id="GeoFS ID of the pilot.")
    # create a discord slash command that adds a pilot to the id storage database with their discord id and geofs id
    async def add_id_storage(self, interaction: discord.Interaction, discord_id: str, geofs_id: str):
        user_role_check = validateUser.validateUser(interaction.user, 3, self.bot.configManager.config)
        if user_role_check[0]:
            await interaction.response.send_message("This command has not been implemented.")
        else:
            if user_role_check[1] is None:
                await interaction.response.send_message("You do not have permission to use this command.")
            else:
                await interaction.response.send_message(user_role_check[1])

    @intelligence_group.command(name="all", description="Get all pilots in the ID storage database.")
    async def get_ids_storage(self, interaction: discord.Interaction):
        user_role_check = validateUser.validateUser(interaction.user, 2, self.bot.configManager.config)
        if user_role_check[0]:
            await interaction.response.send_message("This command has not been implemented.")
        else:
            if user_role_check[1] is None:
                await interaction.response.send_message("You do not have permission to use this command.")
            else:
                await interaction.response.send_message(user_role_check[1])

    @intelligence_group.command(name="callsign-changes", description="Get callsign changes of a GeoFS pilot.")
    @app_commands.describe(geofs_id="GeoFS ID of the pilot.")
    async def get_ccls(self, interaction: discord.Interaction, geofs_id: str):
        # PARITY ISSUE
        # timestamp | Old Callsign | New Callsign
        user_role_check = validateUser.validateUser(interaction.user, 3, self.bot.configManager.config)
        if user_role_check[0]:
            await interaction.response.defer()
            with grpc.insecure_channel("66.179.248.17:50051") as channel:
                stub = database_service_pb2_grpc.DatabaseServiceStub(channel)
                request = database_service_pb2.GetCallsignChangesRequest(geofs_account_id=geofs_id)
                response = stub.GetCallsignChanges(request)
                print(response)
        else:
            if user_role_check[1] is None:
                await interaction.response.send_message("You do not have permission to use this command.")
            else:
                await interaction.response.send_message(user_role_check[1])

    @intelligence_group.command(name="purge-pilots", description="Remove from the ID storage database and add them to the ID database.")
    async def remove_ids_storage(self, interaction: discord.Interaction):
        user_role_check = validateUser.validateUser(interaction.user, 3, self.bot.configManager.config)
        if user_role_check[0]:
            await interaction.response.send_message("This command has not been implemented.")
        else:
            if user_role_check[1] is None:
                await interaction.response.send_message("You do not have permission to use this command.")
            else:
                await interaction.response.send_message(user_role_check[1])

    @intelligence_group.command(name="remove-id", description="Remove a pilot from the ID storage database.")
    @app_commands.describe(discord_id="Discord ID of the pilot.")
    async def remove_id_storage(self, interaction: discord.Interaction, discord_id: str):
        user_role_check = validateUser.validateUser(interaction.user, 3, self.bot.configManager.config)
        if user_role_check[0]:
            await interaction.response.send_message("This command has not been implemented.")
        else:
            if user_role_check[1] is None:
                await interaction.response.send_message("You do not have permission to use this command.")
            else:
                await interaction.response.send_message(user_role_check[1])

async def setup(bot: TreeDiagram):
    await bot.add_cog(Intelligence(bot))